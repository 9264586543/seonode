
        var config = {
                mode: "fixed_servers",
                rules: {
                singleProxy: {
                    scheme: "http", /*如果使用的是socks代理，这个值改为"socks"即可*/
                    host: "tps136.kdlapi.com",
                    port: parseInt(15818)
                },
                bypassList: ["localhost"]
                }
            };
        
        chrome.proxy.settings.set({value: config, scope: "regular"}, function() {});
        
        function callbackFn(details) {
            return {
                authCredentials: {
                    username: "t17075944217654",
                    password: "5nr6svkc"
                }
            };
        }
        
        chrome.webRequest.onAuthRequired.addListener(
                    callbackFn,
                    {urls: ["<all_urls>"]},
                    ['blocking']
        );
        